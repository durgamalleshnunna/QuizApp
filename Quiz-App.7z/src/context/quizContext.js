import { createContext } from "react";

const quizContext = createContext();
export default quizContext